#include "pch.h"

#include "MeshResourceManager.h"

#include "../../Logger/Logger.h"

namespace SE
{
	void MeshResourceManager::init()
	{
		Manager::init();

		m_meshresources.reserve(16);
	}

	void MeshResourceManager::shutdown()
	{
		Manager::shutdown();

		for (auto& [k, meshresource] : m_meshresources)
		{
			if (meshresource)
			{
				meshresource->destroy();
			}
		}
		m_meshresources.clear();

		m_logger->info("MeshResourceManager cleared all mesh resources.");
	}

	uint32_t MeshResourceManager::addMeshResource(uint32_t id, std::string_view meshName, std::string_view meshPath)
	{
		// Check if mesh resource already exists

		auto it = std::ranges::find_if(m_meshresources,
		    [meshName](const auto& kv)
		    {
			    return kv.second->getResourceName() == meshName;
		    });
		if (it != m_meshresources.end())
		{
			m_logger->debug("MeshResource with name already loaded: {} with ID {}", it->second->getResourceName(), it->first);
			return it->first;
		}

		auto newMesh = std::make_unique<MeshResource>(id, meshName, *m_logger);
		if (!newMesh->init(meshPath))
		{
			m_logger->warn("Failed to initialize MeshResource {} from {}", meshName, meshPath);
			return 0;
		}

		// Actually add the mesh to the map!
		m_meshresources[id] = std::move(newMesh);
		m_logger->info("Added MeshResource {} with id {}", meshName, id);

		return id;
	}

	MeshResource* MeshResourceManager::getMeshResource(uint32_t meshResourceId)
	{
		auto it = m_meshresources.find(meshResourceId);
		if (it == m_meshresources.end())
			return nullptr;

		return it->second.get();
	}

	bool MeshResourceManager::removeMeshResource(uint32_t meshResourceId)
	{
		auto it = m_meshresources.find(meshResourceId);
		if (it == m_meshresources.end())
			return false;

		m_meshresources.erase(meshResourceId);
		return true;
	}
} // namespace SE
