#include "pch.h"

#include "SceneSystem.h"

#include "../Events/EventSystem.h"
#include "Engine.h"

namespace SE
{
	void SceneSystem::init()
	{
		SubSystem::init();
	}

	void SceneSystem::update(double deltaTime)
	{
		SubSystem::update(deltaTime);

		if (!m_currentScene && !m_scenes.empty())
		{
			m_currentScene = m_scenes.front().get();
			m_currentScene->initializeScene();
		}

		if (m_currentScene)
		{
			m_currentScene->updateScene(deltaTime);
		}
	}

	void SceneSystem::shutdown()
	{
		SubSystem::shutdown();

		for (auto& scene : m_scenes)
		{
			scene->shutdownScene();
		}

		m_scenes.clear();
		m_currentScene = nullptr;
	}

	void SceneSystem::newScene(const std::string& name)
	{
		m_logger->info("Creating new scene: {}", name);
		auto newScene = std::make_unique<Scene>(name, *m_logger);
		m_scenes.push_back(std::move(newScene));
	}

	void SceneSystem::unloadScene(Scene* scene)
	{
		if (!scene)
		{
			m_logger->warn("Attempted to unload a null scene.");
			return;
		}

		m_logger->info("Unloading scene: {}", scene->getName());
		if (scene == m_currentScene)
		{
			scene->shutdownScene();
			m_currentScene = nullptr;
		}

		m_scenes.erase(std::remove_if(m_scenes.begin(), m_scenes.end(),
		                   [this, scene](const std::unique_ptr<Scene>& s)
		                   {
			                   if (s.get() != scene)
				                   return false;
			                   s->shutdownScene();
			                   if (scene == m_currentScene)
				                   m_currentScene = nullptr;
			                   return true;
		                   }),
		    m_scenes.end());
	}

	void SceneSystem::setCurrentScene(const std::string& name)
	{
		m_logger->info("Setting current scene: {}", name);

		auto it = std::find_if(m_scenes.begin(), m_scenes.end(),
		    [&name](const std::unique_ptr<Scene>& scene)
		    {
			    return scene->getName() == name;
		    });

		if (it != m_scenes.end())
		{
			if (m_currentScene)
				m_currentScene->shutdownScene();

			m_currentScene = it->get();
			m_currentScene->initializeScene();

			Engine::Instance().getSubSystem<EventSystem>()->publish(std::make_unique<SceneChanged>(name));
		}
		else
		{
			m_logger->warn("Scene '{}' not found. Current scene not changed.", name);
		}
	}
} // namespace SE
