#include "pch.h"
#include "EventToLuaBindings.h"
#include "Engine.h"
#include "SubSystems/Events/EventSystem.h"
#include "SubSystems/Events/EventSubscription.h"
#include "SubSystems/Input/KeyCodes.h"

namespace SE
{
	//TODO: only add necessary function to lua since
	// it will generate more unecessary types binding and will bloat the binary
	void SE::EventToLuaBindings::exportEvents(Logger* logger, sol::state& luaState) 
	{
		_exportKeyCodes(logger, luaState);

		// export enum types to lua
		luaState.new_enum("EventType",
			"None", EventType::None,
			"WindowClose", EventType::WindowClose,
			"WindowResize", EventType::WindowResize,
			"WindowFocus", EventType::WindowFocus,
			"WindowLostFocus", EventType::WindowLostFocus,
			"WindowMoved", EventType::WindowMoved,
			"KeyPressed", EventType::KeyPressed,
			"KeyReleased", EventType::KeyReleased,
			"KeyTyped", EventType::KeyTyped,
			"MouseButtonPressed", EventType::MouseButtonPressed,
			"MouseButtonReleased", EventType::MouseButtonReleased,
			"MouseMoved", EventType::MouseMoved,
			"MouseScrolled", EventType::MouseScrolled,
			"SceneChanged", EventType::SceneChanged,
			"ActiveSceneModified", EventType::ActiveSceneModified
			// "EntitySelected", EventType::EntitySelected 
			// "ResourceChanged", EventType::ResourceChanged
		);

		// export Event type to lua
		luaState.new_usertype<Event>("Event",
			"getEventType", &Event::getEventType,
			"getName", &Event::getName
		);

		sol::table eventSystem = luaState.create_named_table("EventSystem");
		eventSystem["publish"] = [](std::unique_ptr<Event>& event)
		{
			auto eventSystem = Engine::Instance().getSubSystem<EventSystem>();
			eventSystem->publish(std::move(event));
		};

		eventSystem.new_usertype<EventSubscription>("EventSubscription",
			sol::constructors<EventSubscription(), EventSubscription(uint32_t, EventType)>(),
			"unsubscribe", &EventSubscription::unsubscribe
		);

		eventSystem["subscribe"] = [logger](EventType eventType, sol::protected_function luaCallback) -> EventSubscription
		{
			auto eventSystem = Engine::Instance().getSubSystem<EventSystem>();

			auto callbackPtr = std::make_shared<sol::protected_function>(std::move(luaCallback));
			return eventSystem->subscribe(eventType, [callbackPtr, logger](Event& event) {
				sol::protected_function_result result = (*callbackPtr)(&event);
				if (!result.valid())
				{
					sol::error err = result;
					logger->error("Lua event callback error: {}", err.what());
				}
			});
		};

	
		_registerEvent<MouseMovedEvent>(luaState);
		_registerEvent<KeyPressedEvent>(luaState);
	}
	void EventToLuaBindings::_exportKeyCodes(Logger* logger, sol::state& luaState)
	{
	
        luaState.new_enum("KeyCodes",
            "KEY_SPACE", KeyCodes::KEY_SPACE,
            "KEY_APOSTROPHE", KeyCodes::KEY_APOSTROPHE,
            "KEY_COMMA", KeyCodes::KEY_COMMA,
            "KEY_MINUS", KeyCodes::KEY_MINUS,
            "KEY_PERIOD", KeyCodes::KEY_PERIOD,
            "KEY_SLASH", KeyCodes::KEY_SLASH,
            "KEY_0", KeyCodes::KEY_0,
            "KEY_1", KeyCodes::KEY_1,
            "KEY_2", KeyCodes::KEY_2,
            "KEY_3", KeyCodes::KEY_3,
            "KEY_4", KeyCodes::KEY_4,
            "KEY_5", KeyCodes::KEY_5,
            "KEY_6", KeyCodes::KEY_6,
            "KEY_7", KeyCodes::KEY_7,
            "KEY_8", KeyCodes::KEY_8,
            "KEY_9", KeyCodes::KEY_9,
            "KEY_SEMICOLON", KeyCodes::KEY_SEMICOLON,
            "KEY_EQUAL", KeyCodes::KEY_EQUAL,
            "KEY_A", KeyCodes::KEY_A,
            "KEY_B", KeyCodes::KEY_B,
            "KEY_C", KeyCodes::KEY_C,
            "KEY_D", KeyCodes::KEY_D,
            "KEY_E", KeyCodes::KEY_E,
            "KEY_F", KeyCodes::KEY_F,
            "KEY_G", KeyCodes::KEY_G,
            "KEY_H", KeyCodes::KEY_H,
            "KEY_I", KeyCodes::KEY_I,
            "KEY_J", KeyCodes::KEY_J,
            "KEY_K", KeyCodes::KEY_K,
            "KEY_L", KeyCodes::KEY_L,
            "KEY_M", KeyCodes::KEY_M,
            "KEY_N", KeyCodes::KEY_N,
            "KEY_O", KeyCodes::KEY_O,
            "KEY_P", KeyCodes::KEY_P,
            "KEY_Q", KeyCodes::KEY_Q,
            "KEY_R", KeyCodes::KEY_R,
            "KEY_S", KeyCodes::KEY_S,
            "KEY_T", KeyCodes::KEY_T,
            "KEY_U", KeyCodes::KEY_U,
            "KEY_V", KeyCodes::KEY_V,
            "KEY_W", KeyCodes::KEY_W,
            "KEY_X", KeyCodes::KEY_X,
            "KEY_Y", KeyCodes::KEY_Y,
            "KEY_Z", KeyCodes::KEY_Z,
            "KEY_LEFT_BRACKET", KeyCodes::KEY_LEFT_BRACKET,
            "KEY_BACKSLASH", KeyCodes::KEY_BACKSLASH,
            "KEY_RIGHT_BRACKET", KeyCodes::KEY_RIGHT_BRACKET,
            "KEY_GRAVE_ACCENT", KeyCodes::KEY_GRAVE_ACCENT,
            "KEY_WORLD_1", KeyCodes::KEY_WORLD_1,
            "KEY_WORLD_2", KeyCodes::KEY_WORLD_2,

            /* Function keys */
            "KEY_ESCAPE", KeyCodes::KEY_ESCAPE,
            "KEY_ENTER", KeyCodes::KEY_ENTER,
            "KEY_TAB", KeyCodes::KEY_TAB,
            "KEY_BACKSPACE", KeyCodes::KEY_BACKSPACE,
            "KEY_INSERT", KeyCodes::KEY_INSERT,
            "KEY_DELETE", KeyCodes::KEY_DELETE,
            "KEY_RIGHT", KeyCodes::KEY_RIGHT,
            "KEY_LEFT", KeyCodes::KEY_LEFT,
            "KEY_DOWN", KeyCodes::KEY_DOWN,
            "KEY_UP", KeyCodes::KEY_UP,
            "KEY_PAGE_UP", KeyCodes::KEY_PAGE_UP,
            "KEY_PAGE_DOWN", KeyCodes::KEY_PAGE_DOWN,
            "KEY_HOME", KeyCodes::KEY_HOME,
            "KEY_END", KeyCodes::KEY_END,
            "KEY_CAPS_LOCK", KeyCodes::KEY_CAPS_LOCK,
            "KEY_SCROLL_LOCK", KeyCodes::KEY_SCROLL_LOCK,
            "KEY_NUM_LOCK", KeyCodes::KEY_NUM_LOCK,
            "KEY_PRINT_SCREEN", KeyCodes::KEY_PRINT_SCREEN,
            "KEY_PAUSE", KeyCodes::KEY_PAUSE,
            "KEY_F1", KeyCodes::KEY_F1,
            "KEY_F2", KeyCodes::KEY_F2,
            "KEY_F3", KeyCodes::KEY_F3,
            "KEY_F4", KeyCodes::KEY_F4,
            "KEY_F5", KeyCodes::KEY_F5,
            "KEY_F6", KeyCodes::KEY_F6,
            "KEY_F7", KeyCodes::KEY_F7,
            "KEY_F8", KeyCodes::KEY_F8,
            "KEY_F9", KeyCodes::KEY_F9,
            "KEY_F10", KeyCodes::KEY_F10,
            "KEY_F11", KeyCodes::KEY_F11,
            "KEY_F12", KeyCodes::KEY_F12,
            "KEY_F13", KeyCodes::KEY_F13,
            "KEY_F14", KeyCodes::KEY_F14,
            "KEY_F15", KeyCodes::KEY_F15,
            "KEY_F16", KeyCodes::KEY_F16,
            "KEY_F17", KeyCodes::KEY_F17,
            "KEY_F18", KeyCodes::KEY_F18,
            "KEY_F19", KeyCodes::KEY_F19,
            "KEY_F20", KeyCodes::KEY_F20,
            "KEY_F21", KeyCodes::KEY_F21,
            "KEY_F22", KeyCodes::KEY_F22,
            "KEY_F23", KeyCodes::KEY_F23,
            "KEY_F24", KeyCodes::KEY_F24,
            "KEY_F25", KeyCodes::KEY_F25,
            "KEY_KP_0", KeyCodes::KEY_KP_0,
            "KEY_KP_1", KeyCodes::KEY_KP_1,
            "KEY_KP_2", KeyCodes::KEY_KP_2,
            "KEY_KP_3", KeyCodes::KEY_KP_3,
            "KEY_KP_4", KeyCodes::KEY_KP_4,
            "KEY_KP_5", KeyCodes::KEY_KP_5,
            "KEY_KP_6", KeyCodes::KEY_KP_6,
            "KEY_KP_7", KeyCodes::KEY_KP_7,
            "KEY_KP_8", KeyCodes::KEY_KP_8,
            "KEY_KP_9", KeyCodes::KEY_KP_9,
            "KEY_KP_DECIMAL", KeyCodes::KEY_KP_DECIMAL,
            "KEY_KP_DIVIDE", KeyCodes::KEY_KP_DIVIDE,
            "KEY_KP_MULTIPLY", KeyCodes::KEY_KP_MULTIPLY,
            "KEY_KP_SUBTRACT", KeyCodes::KEY_KP_SUBTRACT,
            "KEY_KP_ADD", KeyCodes::KEY_KP_ADD,
            "KEY_KP_ENTER", KeyCodes::KEY_KP_ENTER,
            "KEY_KP_EQUAL", KeyCodes::KEY_KP_EQUAL,
            "KEY_LEFT_SHIFT", KeyCodes::KEY_LEFT_SHIFT,
            "KEY_LEFT_CONTROL", KeyCodes::KEY_LEFT_CONTROL,
            "KEY_LEFT_ALT", KeyCodes::KEY_LEFT_ALT,
            "KEY_LEFT_SUPER", KeyCodes::KEY_LEFT_SUPER,
            "KEY_RIGHT_SHIFT", KeyCodes::KEY_RIGHT_SHIFT,
            "KEY_RIGHT_CONTROL", KeyCodes::KEY_RIGHT_CONTROL,
            "KEY_RIGHT_ALT", KeyCodes::KEY_RIGHT_ALT,
            "KEY_RIGHT_SUPER", KeyCodes::KEY_RIGHT_SUPER,
            "KEY_MENU", KeyCodes::KEY_MENU
        );

        luaState.new_enum("MouseCodes",
            "MOUSE_BUTTON_1", MouseCodes::MOUSE_BUTTON_1,
            "MOUSE_BUTTON_2", MouseCodes::MOUSE_BUTTON_2,
            "MOUSE_BUTTON_3", MouseCodes::MOUSE_BUTTON_3,
            "MOUSE_BUTTON_4", MouseCodes::MOUSE_BUTTON_4,
            "MOUSE_BUTTON_5", MouseCodes::MOUSE_BUTTON_5,
            "MOUSE_BUTTON_6", MouseCodes::MOUSE_BUTTON_6,
            "MOUSE_BUTTON_7", MouseCodes::MOUSE_BUTTON_7,
            "MOUSE_BUTTON_8", MouseCodes::MOUSE_BUTTON_8,
            "MOUSE_BUTTON_LAST", MouseCodes::MOUSE_BUTTON_LAST,
            "MOUSE_BUTTON_LEFT", MouseCodes::MOUSE_BUTTON_LEFT,
            "MOUSE_BUTTON_RIGHT", MouseCodes::MOUSE_BUTTON_RIGHT,
            "MOUSE_BUTTON_MIDDLE", MouseCodes::MOUSE_BUTTON_MIDDLE
        );
	}
}
